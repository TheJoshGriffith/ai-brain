// views-kb.jsx — Knowledge Base list: folder tree + tag filter + doc table.
const { useState, useMemo } = React;

function KBView({ docs, onOpen, toggleStar }) {
  const I = window.Icons;
  const { FOLDERS, TAGS, folderName } = window.KB;
  const { EmbedBadge } = window.Lib;

  const [folder, setFolder] = useState("all");
  const [activeTags, setActiveTags] = useState([]);
  const [q, setQ] = useState("");
  const [view, setView] = useState("list");
  const [sort, setSort] = useState("updated");

  const toggleTag = (t) =>
    setActiveTags((a) => (a.includes(t) ? a.filter((x) => x !== t) : [...a, t]));

  const counts = useMemo(() => {
    const c = { all: docs.length, starred: docs.filter((d) => d.star).length };
    FOLDERS.forEach((f) => (c[f.id] = docs.filter((d) => d.folder === f.id).length));
    return c;
  }, [docs]);

  const filtered = useMemo(() => {
    let r = docs;
    if (folder === "starred") r = r.filter((d) => d.star);
    else if (folder !== "all") r = r.filter((d) => d.folder === folder);
    if (activeTags.length) r = r.filter((d) => activeTags.every((t) => d.tags.includes(t)));
    if (q.trim()) {
      const k = q.toLowerCase();
      r = r.filter((d) => d.title.toLowerCase().includes(k) || d.tags.some((t) => t.includes(k)));
    }
    r = [...r];
    if (sort === "title") r.sort((a, b) => a.title.localeCompare(b.title));
    else if (sort === "reads") r.sort((a, b) => b.reads - a.reads);
    // "updated" keeps source order (already newest-ish)
    return r;
  }, [docs, folder, activeTags, q, sort]);

  return (
    <div className="kb-grid">
      <aside className="kb-aside">
        <h4>Library</h4>
        <button className="tree-item" data-active={folder === "all"} onClick={() => setFolder("all")}>
          <I.layers /><span>All documents</span><span className="count">{counts.all}</span>
        </button>
        <button className="tree-item" data-active={folder === "starred"} onClick={() => setFolder("starred")}>
          <I.star /><span>Starred</span><span className="count">{counts.starred}</span>
        </button>

        <h4>Folders</h4>
        {FOLDERS.map((f) => (
          <button key={f.id} className="tree-item" data-active={folder === f.id} onClick={() => setFolder(f.id)}>
            {folder === f.id ? <I.folderOpen /> : <I.folder />}
            <span>{f.name}</span><span className="count">{counts[f.id]}</span>
          </button>
        ))}

        <h4>Tags</h4>
        <div className="tag-cloud">
          {TAGS.map((t) => (
            <button key={t} className="tag" data-on={activeTags.includes(t)} onClick={() => toggleTag(t)}>{t}</button>
          ))}
        </div>
      </aside>

      <div className="kb-main">
        <div className="wrap wrap-wide">
          <div className="page-head">
            <div>
              <h1 className="page-title">
                {folder === "all" ? "All documents" : folder === "starred" ? "Starred" : folderName(folder)}
              </h1>
              <p className="page-sub">
                {filtered.length} document{filtered.length === 1 ? "" : "s"}
                {activeTags.length > 0 && <> · filtered by {activeTags.map((t) => "#" + t).join(", ")}</>}
                {" · indexed for MCP retrieval"}
              </p>
            </div>
            <div className="actions">
              <button className="btn btn-sm"><I.download />Export</button>
              <button className="btn btn-primary btn-sm"><I.plus />New document</button>
            </div>
          </div>

          <div className="toolbar">
            <div className="filter-input">
              <I.search />
              <input placeholder="Filter documents…" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <div className="seg">
              <button data-on={sort === "updated"} onClick={() => setSort("updated")}><I.clock />Updated</button>
              <button data-on={sort === "reads"} onClick={() => setSort("reads")}><I.bot />Reads</button>
              <button data-on={sort === "title"} onClick={() => setSort("title")}>A–Z</button>
            </div>
            <div className="seg" style={{ marginLeft: "auto" }}>
              <button data-on={view === "list"} onClick={() => setView("list")}><I.list /></button>
              <button data-on={view === "grid"} onClick={() => setView("grid")}><I.grid /></button>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="empty">
              <I.search /><h3>No documents match</h3>
              <p>Try clearing tags or the filter.</p>
            </div>
          ) : view === "list" ? (
            <table className="tbl fade-in">
              <thead>
                <tr>
                  <th style={{ width: 26 }}></th>
                  <th>Document</th>
                  <th style={{ width: 220 }}>Tags</th>
                  <th style={{ width: 110 }}>Status</th>
                  <th style={{ width: 96 }}>Agent reads</th>
                  <th style={{ width: 120 }}>Updated</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((d) => (
                  <tr key={d.id} onClick={() => onOpen(d.id)}>
                    <td onClick={(e) => { e.stopPropagation(); toggleStar(d.id); }}>
                      <span className="star" data-on={d.star} title="Star"><I.star /></span>
                    </td>
                    <td>
                      <div className="doc-cell">
                        <span className="doc-ico"><I.file /></span>
                        <span style={{ minWidth: 0, flex: 1 }}>
                          <div className="doc-title">{d.title}</div>
                          <div className="doc-path">{folderName(d.folder)}</div>
                        </span>
                      </div>
                    </td>
                    <td>
                      <div className="tags-cell">
                        {d.tags.slice(0, 3).map((t) => <span key={t} className="tag" style={{ pointerEvents: "none" }}>{t}</span>)}
                      </div>
                    </td>
                    <td><EmbedBadge status={d.embed} /></td>
                    <td className="mono">{d.reads.toLocaleString()}</td>
                    <td className="muted" style={{ whiteSpace: "nowrap" }}>{d.updated}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="fade-in" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(260px,1fr))", gap: 12 }}>
              {filtered.map((d) => (
                <div key={d.id} className="stat" style={{ cursor: "pointer", gap: 10 }} onClick={() => onOpen(d.id)}>
                  <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                    <span className="doc-ico" style={{ color: "var(--fg-faint)" }}><I.file /></span>
                    <span className="doc-title" style={{ fontWeight: 600 }}>{d.title}</span>
                    <span className="star" data-on={d.star} style={{ marginLeft: "auto" }} onClick={(e) => { e.stopPropagation(); toggleStar(d.id); }}><I.star /></span>
                  </div>
                  <div className="tags-cell">{d.tags.slice(0, 3).map((t) => <span key={t} className="tag" style={{ pointerEvents: "none" }}>{t}</span>)}</div>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 2 }}>
                    <EmbedBadge status={d.embed} />
                    <span className="mono" style={{ fontSize: 11, color: "var(--fg-faint)" }}>{d.reads.toLocaleString()} reads</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

window.KBView = KBView;
