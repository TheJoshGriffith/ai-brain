// views-settings.jsx — settings with the MCP server config + status indicators.
const { useState: useStateS } = React;

function SettingsView() {
  const I = window.Icons;
  const { MCP_TOOLS } = window.KB;
  const [enabled, setEnabled] = useStateS({ search_docs: true, read_doc: true, write_doc: true, list_folders: true, get_history: false });
  const [copied, setCopied] = useStateS(false);
  const [autoIndex, setAutoIndex] = useStateS(true);
  const [requireScopes, setRequireScopes] = useStateS(true);

  const toggle = (k) => setEnabled((e) => ({ ...e, [k]: !e[k] }));
  const copy = () => { setCopied(true); setTimeout(() => setCopied(false), 1400); };

  return (
    <div className="content">
      <div className="wrap">
        <div className="page-head">
          <div>
            <h1 className="page-title">Settings</h1>
            <p className="page-sub">Configure the knowledge base and the built-in MCP server that agents connect to.</p>
          </div>
        </div>

        {/* MCP server */}
        <div className="panel-card">
          <div className="ph">
            <span className="ico" style={{ color: "var(--accent)", background: "var(--accent-soft)", borderColor: "var(--accent-line)" }}><I.plug /></span>
            <div>
              <h3 style={{ display: "flex", alignItems: "center", gap: 9 }}>MCP Server
                <span className="badge"><i className="dot dot-green" />operational</span>
              </h3>
              <p>Model Context Protocol endpoint. This is how every agent reads and writes the knowledge base.</p>
            </div>
            <div className="actions"><button className="btn btn-sm"><I.history />Logs</button></div>
          </div>
          <div className="pb">
            <div className="cfg-row">
              <div className="lbl"><div className="t">Endpoint</div><div className="d">SSE transport URL</div></div>
              <div className="ctl">
                <div className="code-field">
                  <span><span className="tok-green">https://</span>mcp.ai-brain.dev<span className="tok-purple">/sse</span></span>
                </div>
                <button className="btn btn-sm" onClick={copy}>{copied ? <><I.check />Copied</> : <><I.copy />Copy</>}</button>
              </div>
            </div>
            <div className="cfg-row">
              <div className="lbl"><div className="t">Client config</div><div className="d">Drop into mcp.json</div></div>
              <div className="ctl">
                <div className="code-field" style={{ whiteSpace: "pre", lineHeight: 1.6, display: "block" }}>
{`{
  `}<span className="tok-purple">"ai-brain"</span>{`: {
    `}<span className="tok-purple">"url"</span>{`: `}<span className="tok-str">"https://mcp.ai-brain.dev/sse"</span>{`,
    `}<span className="tok-purple">"headers"</span>{`: { `}<span className="tok-purple">"Authorization"</span>{`: `}<span className="tok-str">"Bearer abk_live_…"</span>{` }
  }
}`}
                </div>
              </div>
            </div>
            <div className="cfg-row">
              <div className="lbl"><div className="t">Index health</div><div className="d">Vector store status</div></div>
              <div className="ctl" style={{ gap: 20 }}>
                <span className="badge"><i className="dot dot-green" />12,418 chunks</span>
                <span className="hint mono" style={{ fontFamily: "var(--font-mono)" }}>p50 query 38ms</span>
                <span className="hint mono" style={{ fontFamily: "var(--font-mono)" }}>2 pending</span>
              </div>
            </div>
          </div>
        </div>

        {/* Exposed tools */}
        <div className="panel-card">
          <div className="ph">
            <span className="ico"><I.zap /></span>
            <div><h3>Exposed tools</h3><p>Toggle which MCP tools connected agents can call.</p></div>
          </div>
          <div className="pb">
            {MCP_TOOLS.map((t) => (
              <div className="tool-row" key={t.name}>
                <span className="avatar" style={{ background: "var(--panel-2)", border: "1px solid var(--border)", color: "var(--fg-muted)" }}><I.zap /></span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="mono-name">{t.name}<span style={{ color: "var(--fg-faint)" }}>()</span></div>
                  <div className="desc">{t.desc}</div>
                </div>
                <div style={{ display: "flex", gap: 4 }}>{t.scopes.map((s) => <span key={s} className="scope-tag">{s}</span>)}</div>
                <button className="switch" data-on={enabled[t.name]} onClick={() => toggle(t.name)}><i /></button>
              </div>
            ))}
          </div>
        </div>

        {/* Indexing prefs */}
        <div className="panel-card">
          <div className="ph">
            <span className="ico"><I.db /></span>
            <div><h3>Indexing & retrieval</h3><p>How documents become agent-readable knowledge.</p></div>
          </div>
          <div className="pb">
            <div className="cfg-row">
              <div className="lbl"><div className="t">Auto-index on write</div><div className="d">Re-embed changed chunks immediately</div></div>
              <div className="ctl"><button className="switch" data-on={autoIndex} onClick={() => setAutoIndex(!autoIndex)}><i /></button></div>
            </div>
            <div className="cfg-row">
              <div className="lbl"><div className="t">Embedding model</div><div className="d">Used for semantic retrieval</div></div>
              <div className="ctl">
                <select className="field mono" style={{ maxWidth: 280 }} defaultValue="3-large">
                  <option value="3-large">text-embedding-3-large · 3072d</option>
                  <option value="3-small">text-embedding-3-small · 1536d</option>
                  <option value="inhouse">ai-brain-embed-v1 (beta)</option>
                </select>
              </div>
            </div>
            <div className="cfg-row">
              <div className="lbl"><div className="t">Enforce scopes on read</div><div className="d">Agents only retrieve folders they can access</div></div>
              <div className="ctl"><button className="switch" data-on={requireScopes} onClick={() => setRequireScopes(!requireScopes)}><i /></button></div>
            </div>
            <div className="cfg-row">
              <div className="lbl"><div className="t">Chunk size</div><div className="d">Tokens per embedded chunk</div></div>
              <div className="ctl"><input className="field mono" style={{ maxWidth: 120 }} defaultValue="512" /><span className="hint">64-token overlap</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.SettingsView = SettingsView;
