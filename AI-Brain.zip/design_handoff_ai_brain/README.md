# Handoff: AI-Brain — Document Management System with Built-in MCP

## Overview
AI-Brain is a document management system for developers that doubles as an AI
agent's source of truth. It exposes a built-in **MCP (Model Context Protocol)
server** so coding agents (Claude Code, Cursor, custom bots) can read, search,
and write the same knowledge base that humans edit in the UI. Every write —
human or agent — flows through a single MCP write path, keeping the vector
index and permissions consistent.

The app has four top-level areas: **Knowledge base** (browse/filter docs),
**Editor** (markdown editor with index + activity metadata), **Search**
(⌘K palette with full-text and semantic modes), **Access control**
(members + agent tokens), and **Settings** (MCP server config + tool toggles).

## About the Design Files
The files in this bundle are **design references created in HTML/React (via
in-browser Babel)** — a working prototype that demonstrates the intended look,
layout, and interactions. **They are not production code to copy directly.**

The task is to **recreate these designs in the target codebase's environment.**
The intended target (per the brief) is **Next.js + Tailwind CSS**. Rebuild the
screens as React components using the project's established patterns, routing,
and data layer. The prototype's mock data, fake "semantic" scoring, and the
hand-rolled markdown renderer are stand-ins — replace them with real APIs, a
real vector store, and a real markdown library (e.g. `react-markdown`).

## Fidelity
**High-fidelity.** Colors, typography, spacing, density, dark/light theming,
and interactions are final and intended to be matched closely. Exact tokens are
listed under **Design Tokens**. Recreate pixel-for-pixel using Tailwind theme
extensions mapped to the CSS variables below.

## Locked Configuration (product defaults)
These were chosen from the exploration and should be the shipped defaults:
- **Navigation:** icon **rail** (56px), not the full sidebar.
- **Typeface:** **Geist** (sans) + **Geist Mono** (mono).
- **Editor:** **toggle** mode (Edit / Split / Preview switch).
- **Theme:** **follows the OS** by default (`prefers-color-scheme`), with an
  explicit System / Light / Dark override available to the user.
- **Density:** regular.
- **User-configurable settings to expose in the real app:** Theme
  (System/Light/Dark) and **Accent color**. Everything else is locked.

---

## Screens / Views

### 1. App Shell
- **Layout:** CSS grid, two columns: a **56px icon rail** + `1fr` main area.
  (Prototype also supports a 248px labeled sidebar and a horizontal top-nav;
  ship the rail.)
- **Rail (left):** vertical, `--panel` background, `1px` right border
  (`--border`). Top: 26×26 brand mark (rounded 7px, solid `--fg` background,
  brain glyph in `--bg` color), centered. Below: nav icons (Knowledge base,
  Search, Access control, Settings), each 34px tall, centered icon (16px),
  `--fg-muted` default → `--fg` on hover (`--panel-2` bg). Active item:
  `--panel-3` bg + a 3px `--accent` indicator bar on the left edge. Labels are
  hidden in rail mode; show as `title=` tooltips.
- **Top bar (in main):** 53px tall, `1px` bottom border, sticky, translucent
  `--panel` with `backdrop-filter: blur(8px)`. Contains: breadcrumbs (left),
  flexible spacer, a **search button** (opens the ⌘K palette — pill, `--panel-2`
  bg, search icon + "Search…" + `⌘K` kbd chip), a history icon button, and a
  primary **New** button.
- **Breadcrumbs:** plain text segments separated by chevron icons. Non-final
  segments are `--fg-muted` and clickable (→ `--fg` on hover); the final segment
  is `--fg`, weight 500. (Note: do NOT give these a border/background box.)

### 2. Knowledge Base (route: `kb`) — home
- **Layout:** two columns inside the main area: a **232px left aside**
  (folder tree + tags) + `1fr` document list.
- **Left aside** (`--panel` bg, `1px` right border, 18px/14px padding):
  - Section labels ("Library", "Folders", "Tags"): 10.5px, weight 600,
    uppercase, `0.07em` tracking, `--fg-faint`.
  - **Library:** "All documents" (layers icon + count), "Starred" (star + count).
  - **Folders:** one row per folder (folder icon → open-folder icon when active,
    name, right-aligned mono count). 30px tall, 7px radius, hover `--panel-2`,
    active `--panel-3` + weight 500.
  - **Tags:** wrapped pill cloud. Each tag is a mono 11px pill with a `#` prefix
    (in `--fg-faint`), `1px --border`, `--panel` bg. Toggled-on tags use
    `--accent` text, `--accent-line` border, `--accent-soft` bg.
- **Document list area** (max-width 100%, 22–28px padding):
  - **Page head:** title (21px, weight 600, `-0.02em`), subtitle (`--fg-muted`,
    13px: e.g. "12 documents · indexed for MCP retrieval"), right-aligned
    actions: secondary **Export** (download icon) + primary **New document**.
  - **Toolbar:** filter input (search icon + text input, `--panel`, max 320px),
    a sort segmented control (Updated / Reads / A–Z), and a right-aligned
    list/grid view toggle.
  - **Table** (list view): columns — star toggle (26px), **Document**, **Tags**
    (220px), **Status** (110px), **Agent reads** (96px), **Updated** (120px).
    - Header cells: 11px, weight 600, uppercase, `0.03em`, `--fg-faint`, bottom
      border.
    - Rows: `--pad-y` vertical padding, `1px` bottom border, pointer cursor,
      hover `--panel-2`. Clicking a row opens the editor.
    - Document cell: file icon (`--fg-faint`) + title (weight 500, fills cell)
      over a mono 11px folder path (`--fg-faint`).
    - Star: hollow star, `--fg-faint`; starred = amber `oklch(0.78 0.16 75)`.
      Click toggles without opening the doc (`stopPropagation`).
    - Tags cell: up to 3 tag pills.
    - Status: **embedding status badge** — green dot "indexed",
      amber dot "pending", gray dot "stale" (mono 11px badge).
    - Agent reads: mono, tabular-nums, locale-formatted (e.g. `1,284`).
  - **Grid view:** responsive cards (`minmax(260px,1fr)`), each with title + file
    icon + star, tag pills, and a status badge + reads footer.
  - **Empty state:** centered search icon + "No documents match" + hint.

### 3. Editor (route: `editor`)
- **Layout:** two columns: `1fr` editor + **300px right metadata aside**.
- **Editor bar** (11px/22px padding, bottom border): back chevron, a segmented
  control (**Edit / Split / Preview** in toggle mode), a `v12` version badge,
  flexible spacer, a mono status hint ("153 words · saved via `write_doc`" with
  `write_doc` in `--accent`), a **Copy** button, and a primary **Saved** button.
- **Edit pane:** centered paper, max-width 760px, 34/40px padding.
  - Title input: 30px, weight 700, `-0.025em`, borderless, Geist sans.
  - Tag row: existing tag pills + a dashed "+ add tag" pill.
  - Body: full-width `<textarea>`, **Geist Mono** 13.5px, line-height 1.8,
    `tab-size: 2`, borderless. (In production, back this with a real markdown
    editor; preview uses a markdown renderer.)
- **Preview pane:** rendered markdown (`.md` styles — headings, lists, tables,
  fenced code blocks in `--panel-2` boxes, inline code chips, blockquotes with
  `--accent-line` left border, links in `--accent`).
- **Split mode:** edit (left, `1px` divider) + live preview (right), 50/50.
- **Metadata aside** (`--panel` bg, `1px` left border, 18px padding, three
  blocks separated by 20px gaps; block headings are 10.5px uppercase
  `--fg-faint`):
  - **Properties:** Folder, Access (badge: globe "public" / users "team" /
    lock "private"), Author, Updated. Each row: `--fg-muted` label (icon + text)
    left, `--fg` value right; values never wrap.
  - **Index status:** Embedding (status badge), Chunks (mono count), Agent reads
    (mono), plus a full-width **Re-index now** button (sparkle icon).
  - **Recent activity:** stacked feed. Each entry: a 22px rounded avatar — agent
    entries use a bot icon in `--accent-soft`/`--accent`/`--accent-line`; humans
    use initials in `--panel-3`. Then "<who> <what>" (who weight 500, what
    `--fg-muted`) over a mono 10.5px timestamp (`--fg-faint`). Keep entries short
    so they stay one line.

### 4. Search Palette (⌘K overlay)
- **Trigger:** `⌘K` / `Ctrl+K` toggles it; also the top-bar search button and the
  rail Search item.
- **Overlay:** full-viewport `--overlay` scrim + `blur(2px)`, content offset 12vh
  from top.
- **Palette:** max-width 640px, `--panel`, `1px --border-strong`, 12px radius,
  `--shadow-md`, max-height 64vh.
  - **Input row:** search icon + 16px text input + a **mode toggle** (two mono
    pills: "semantic" | "full-text"; active pill uses accent colors).
  - **List:** section label ("Suggested" when empty, else result count + mode
    description). Each result row: file icon, title (weight 500), snippet
    (`--fg-muted` 12px; the matched term wrapped in `<mark>` styled with
    `--accent-soft` bg + `--accent` text), a right-aligned similarity score
    (mono, `--accent`, e.g. `87%`, semantic mode only), and a mono folder path.
    Active row (keyboard/hover) = `--panel-3`.
  - **Footer:** kbd hints (↑ ↓ navigate, ↵ open, esc close) + "via `search_docs`".
- **Behavior:** ↑/↓ move selection, ↵ opens, Esc closes, click scrim closes.
  - **full-text mode:** substring match on title + body.
  - **semantic mode:** prototype fakes a similarity score via token/concept
    overlap + title boost, sorted desc. **Replace with real vector retrieval**
    (dense + sparse / RRF) hitting the `search_docs` MCP tool.

### 5. Access Control (route: `access`)
- **Layout:** single centered column (max-width 1080px).
- **Page head:** title + descriptive subtitle; actions: **Invite** + primary
  **New agent token**.
- **Stat row:** 4 stat cards (Members, Agent tokens, Active now, Roles) — each a
  bordered `--panel` card: 11px label (icon + text) over a 22px weight-600 value.
- **People panel card** (rounded 10px, header with icon tile + title + sub):
  table of members — avatar (initials, hue-tinted) + name + email, role badge
  (Owner uses the accent badge variant), scope summary, last-active, overflow
  menu (kebab).
- **Agent tokens panel card:** table of MCP connections — bot avatar + mono
  connection name + masked token (`abk_live_••••…`), client, scope tags
  (mono chips in `--panel-3`), activity (`reads↓ writes↑`, mono), last-seen
  badge (green dot if active, gray if idle), kebab menu.

### 6. Settings (route: `settings`)
- **Layout:** single centered column. Three panel cards.
- **MCP Server card** (accent-tinted icon tile): header shows an "operational"
  green-dot badge. Rows:
  - **Endpoint:** a mono **code field** showing `https://mcp.ai-brain.dev/sse`
    (with simple syntax-color spans) + a Copy button that flips to "Copied" for
    ~1.4s.
  - **Client config:** a multi-line mono code block (the `mcp.json` snippet).
  - **Index health:** badges — "12,418 chunks" (green dot), "p50 query 38ms",
    "2 pending".
- **Exposed tools card:** one row per MCP tool (`search_docs`, `read_doc`,
  `write_doc`, `list_folders`, `get_history`): zap-icon tile, mono tool name
  with `()`, description, scope chips, and an iOS-style **switch**
  (`--accent` when on). `get_history` is off by default in the prototype.
- **Indexing & retrieval card:** config rows — Auto-index on write (switch),
  Embedding model (select), Enforce scopes on read (switch), Chunk size (input).

---

## Interactions & Behavior
- **Routing:** single-page state machine (`kb` → `editor` → back; `access`;
  `settings`). In Next.js, use real routes (`/`, `/doc/[id]`, `/access`,
  `/settings`) and a modal/parallel route for the ⌘K palette.
- **Open doc:** clicking a table row or a palette result sets the open doc and
  routes to the editor.
- **Star toggle:** optimistic local toggle; stop propagation so it doesn't open.
- **Editor edits:** title/body update local state and a word count derived from
  the body. Wire to the real `write_doc` endpoint (debounced autosave).
- **⌘K palette:** global key listener toggles; full keyboard nav inside.
- **Copy buttons:** show transient "Copied" confirmation.
- **Theme:** `data-theme="light|dark"` on `<html>`. Default reads
  `matchMedia('(prefers-color-scheme: dark)')` and **subscribes to changes**;
  explicit Light/Dark override wins over System.
- **Accent:** set the `--accent` CSS variable; all accent-derived tokens use
  `color-mix(in oklch, var(--accent) …)` so changing one variable recolors
  badges, active states, links, switches, etc.
- **Entrance motion:** table/grid fade in with a 4px translateY (transform only —
  never gate content visibility behind opacity animations).

## State Management
- `route`, `openId` (current doc), `paletteOpen`, `docs` (list w/ star + edits),
  and tweak/config state (`theme`, `accent`).
- Per-view local state: KB filters (folder, active tags, query, sort, view);
  editor (title, body, mode); settings (tool enable map, toggles); palette
  (query, mode, selection index).
- Replace mock `docs`/`activity`/`agents`/`members` with API queries; persist
  edits via `write_doc`; back search with the vector store.

## Design Tokens

### Typography
- Sans: **Geist** (400/500/600/700). Mono: **Geist Mono** (400/500/600).
- Base body 13.5px / line-height 1.5 (regular density). Page titles 21px/600;
  doc H1 30px/700; section labels 10.5px/600 uppercase `0.07em`.
- Density scale — compact: text 13px, row 30px, pad-y 5px, gap 10px, radius 6px ·
  regular: 13.5 / 34 / 7 / 14 / 7 · comfortable: 14.5 / 42 / 11 / 18 / 8.

### Colors — Light (`[data-theme="light"]`)
- `--bg #fcfcfc` · `--panel #ffffff` · `--panel-2 #f8f8f8` · `--panel-3 #f2f2f2`
- `--border rgba(0,0,0,.085)` · `--border-strong rgba(0,0,0,.16)`
- `--fg #18181b` · `--fg-muted #6a6a72` · `--fg-faint #9a9aa2`
- `--overlay rgba(20,20,22,.32)`

### Colors — Dark (`[data-theme="dark"]`)
- `--bg #0a0a0b` · `--panel #111113` · `--panel-2 #161618` · `--panel-3 #1d1d20`
- `--border rgba(255,255,255,.08)` · `--border-strong rgba(255,255,255,.16)`
- `--fg #ededee` · `--fg-muted #9b9ba3` · `--fg-faint #6a6a72`
- `--overlay rgba(0,0,0,.55)`

### Accent (user-configurable)
- Default `#3565F6`. Options: `#7A5AF0`, `#16A06A`, `#E0822A`, `#E0473C`.
- Derived: `--accent-soft = color-mix(in oklch, accent 12%, transparent)`,
  `--accent-line = color-mix(in oklch, accent 38%, transparent)`,
  `--accent-fg = #fff`. Primary button hover = `color-mix(accent 88%, black)`.

### Status colors
- Green (indexed/active): `oklch(0.72 0.17 150)` · Amber (pending):
  `oklch(0.78 0.16 75)` · Gray (stale/idle): `--fg-faint`. Dots are 7px with a
  soft 3px ring at 20% alpha.

### Radius / shadow / spacing
- Radius: `--radius` 7px (regular); cards 10–12px; pills/badges 5–6px.
- `--shadow-sm` (light): `0 1px 2px rgba(0,0,0,.05)`;
  `--shadow-md`: `0 6px 24px rgba(0,0,0,.10), 0 1px 3px rgba(0,0,0,.06)`.
  (Dark theme uses deeper shadows — see `styles.css`.)
- Rhythm uses `--gap` (14px regular) and `--pad-y` (7px regular).

## Assets
- **Fonts:** Geist + Geist Mono (also IBM Plex Sans/Mono and Space Grotesk/Mono
  are loaded for the alt typefaces, but Geist is the shipped default) — via
  Google Fonts in the prototype. Use `next/font` (`Geist`, `Geist_Mono`) in Next.
- **Icons:** a custom stroke-based set (1.7 stroke width, round caps/joins,
  `currentColor`) in `icons.jsx`. They mirror Lucide geometry — in production use
  **lucide-react** (brain, file, search, folder, shield, settings, plug, star,
  tag, clock, users, bot, eye, edit, history, database, layers, zap, etc.).
- **No raster images** — the design is entirely type + icons + color.

## Files (in this bundle)
- `AI-Brain.html` — entry point; loads fonts, React, and the scripts below.
- `styles.css` — **the design system** (all tokens, theming, every component
  class). This is the most important file to port to Tailwind theme + components.
- `shell.jsx` — app shell, rail nav, top bar, routing, theme/accent logic, Tweaks.
- `views-kb.jsx` — knowledge base (folder tree, tags, table/grid).
- `views-editor.jsx` — editor (edit/split/preview + metadata aside).
- `palette.jsx` — ⌘K search palette (full-text + semantic).
- `views-access.jsx` — access control (members + agent tokens).
- `views-settings.jsx` — settings + MCP config.
- `lib.jsx` — markdown renderer + shared atoms (badges, avatar).
- `data.jsx` — mock data (folders, docs, tags, agents, members, MCP tools).
- `icons.jsx` — icon set.
- `tweaks-panel.jsx` — the in-prototype Tweaks panel (design-tool only; do not
  ship — instead expose Theme + Accent in the real Settings screen).

## Implementation Notes for Next.js + Tailwind
- Map the CSS variables above into `tailwind.config` (`theme.extend.colors` via
  `rgb(var(--…))` or use the variables directly with arbitrary values). Drive
  light/dark by toggling `data-theme` on `<html>` (Tailwind `darkMode: ['class']`
  or a custom variant keyed off the attribute).
- Recreate the accent system with CSS variables + `color-mix` so a single accent
  change recolors the whole UI (matches the prototype).
- Use `react-markdown` + `remark-gfm` for the preview (tables, code, lists).
- The MCP server, vector index, auth/scopes, and tool endpoints are real backend
  work — the UI only visualizes their state (status badges, activity, tokens).
