// views-editor.jsx — document editor: edit / preview / split, plus meta sidebar.
const { useState: useStateE } = React;

function EditorView({ doc, editorMode, onChange, onBack }) {
  const I = window.Icons;
  const { Markdown, EmbedBadge, AccessBadge, Avatar } = window.Lib;
  const { ACTIVITY, folderName } = window.KB;

  // editorMode tweak: "toggle" (switchable), "split" (live), "focus" (preview-only writing feel)
  const [mode, setMode] = useStateE(editorMode === "split" ? "split" : "edit");
  React.useEffect(() => { setMode(editorMode === "split" ? "split" : "edit"); }, [editorMode, doc.id]);

  const [body, setBody] = useStateE(doc.body);
  const [title, setTitle] = useStateE(doc.title);
  React.useEffect(() => { setBody(doc.body); setTitle(doc.title); }, [doc.id]);

  const words = body.trim() ? body.trim().split(/\s+/).length : 0;
  const showToggle = editorMode === "toggle";

  const EditorPane = (
    <div className="editor-paper">
      <input className="doc-h1" value={title} placeholder="Untitled document"
             onChange={(e) => { setTitle(e.target.value); onChange(doc.id, { title: e.target.value }); }} />
      <div style={{ display: "flex", gap: 6, marginBottom: 18, flexWrap: "wrap" }}>
        {doc.tags.map((t) => <span key={t} className="tag" style={{ pointerEvents: "none" }}>{t}</span>)}
        <span className="tag" style={{ borderStyle: "dashed", color: "var(--fg-faint)" }}>+ add tag</span>
      </div>
      <textarea className="editor-area" value={body} spellCheck={false}
                onChange={(e) => { setBody(e.target.value); onChange(doc.id, { body: e.target.value, words }); }} />
    </div>
  );

  const PreviewPane = (
    <div className="editor-paper">
      <Markdown source={body} />
    </div>
  );

  return (
    <div className="editor-grid">
      <div className="editor-main">
        <div className="editor-bar">
          <button className="btn btn-ghost btn-sm" onClick={onBack}><I.chevR /></button>
          {showToggle ? (
            <div className="seg">
              <button data-on={mode === "edit"} onClick={() => setMode("edit")}><I.edit />Edit</button>
              <button data-on={mode === "split"} onClick={() => setMode("split")}><I.layers />Split</button>
              <button data-on={mode === "preview"} onClick={() => setMode("preview")}><I.preview />Preview</button>
            </div>
          ) : (
            <div className="seg">
              <button data-on={mode === "edit"} onClick={() => setMode("edit")}><I.edit />Edit</button>
              <button data-on={mode === "split"} onClick={() => setMode("split")}><I.layers />Split</button>
            </div>
          )}
          <span className="badge" style={{ marginLeft: 4 }}><I.history />v12</span>
          <div className="spacer" style={{ flex: 1 }} />
          <span className="hint" style={{ fontFamily: "var(--font-mono)", fontSize: 11.5 }}>
            {words} words · saved via <span style={{ color: "var(--accent)" }}>write_doc</span>
          </span>
          <button className="btn btn-sm"><I.copy />Copy</button>
          <button className="btn btn-primary btn-sm"><I.check />Saved</button>
        </div>

        <div className="editor-scroll">
          {mode === "split" ? (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", minHeight: "100%" }}>
              <div style={{ borderRight: "1px solid var(--border)" }}>{EditorPane}</div>
              <div>{PreviewPane}</div>
            </div>
          ) : mode === "preview" ? PreviewPane : EditorPane}
        </div>
      </div>

      <aside className="editor-aside">
        <div className="meta-block">
          <h5>Properties</h5>
          <div className="meta-row"><span className="k"><I.folder />Folder</span><span className="v">{folderName(doc.folder)}</span></div>
          <div className="meta-row"><span className="k"><I.shield />Access</span><span className="v"><AccessBadge access={doc.access} /></span></div>
          <div className="meta-row"><span className="k"><I.user />Author</span><span className="v">{doc.by.replace(/^agent · /, "")}</span></div>
          <div className="meta-row"><span className="k"><I.clock />Updated</span><span className="v mono">{doc.updated}</span></div>
        </div>

        <div className="meta-block">
          <h5>Index status</h5>
          <div className="meta-row"><span className="k"><I.db />Embedding</span><span className="v"><EmbedBadge status={doc.embed} /></span></div>
          <div className="meta-row"><span className="k"><I.layers />Chunks</span><span className="v mono">{Math.max(1, Math.ceil(words / 180))}</span></div>
          <div className="meta-row"><span className="k"><I.bot />Agent reads</span><span className="v mono">{doc.reads.toLocaleString()}</span></div>
          <button className="btn btn-sm" style={{ width: "100%", marginTop: 4 }}><I.spark />Re-index now</button>
        </div>

        <div className="meta-block">
          <h5>Recent activity</h5>
          <div className="activity">
            {ACTIVITY.map((a, idx) => (
              <div className="act" key={idx}>
                <span className={"ava " + (a.kind === "agent" ? "agent" : "human")}>
                  {a.kind === "agent" ? <I.bot /> : window.KB.initials(a.who)}
                </span>
                <div className="body">
                  <div><span className="who">{a.who}</span> <span className="what">{a.what}</span></div>
                  <div className="when">{a.when}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}

window.EditorView = EditorView;
