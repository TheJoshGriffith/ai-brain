// lib.jsx — markdown renderer + shared UI atoms, exported to window.

// Minimal but capable markdown -> HTML. Handles headings, lists, tables,
// code fences, inline code, bold/italic, links, blockquotes, hr.
function mdToHtml(src) {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const inline = (s) => esc(s)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');

  const lines = src.replace(/\r/g, "").split("\n");
  let html = "", i = 0;
  while (i < lines.length) {
    let line = lines[i];

    // code fence
    if (/^```/.test(line)) {
      const lang = line.slice(3).trim();
      let code = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) { code.push(lines[i]); i++; }
      i++;
      html += `<pre data-lang="${lang}"><code>${esc(code.join("\n"))}</code></pre>`;
      continue;
    }
    // table
    if (/\|/.test(line) && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|?\s*$/.test(lines[i + 1]) && lines[i + 1].includes("-")) {
      const parseRow = (r) => r.replace(/^\s*\|/, "").replace(/\|\s*$/, "").split("|").map(c => c.trim());
      const head = parseRow(line);
      i += 2;
      let rows = [];
      while (i < lines.length && lines[i].includes("|")) { rows.push(parseRow(lines[i])); i++; }
      html += "<table><thead><tr>" + head.map(h => `<th>${inline(h)}</th>`).join("") + "</tr></thead><tbody>";
      html += rows.map(r => "<tr>" + r.map(c => `<td>${inline(c)}</td>`).join("") + "</tr>").join("");
      html += "</tbody></table>";
      continue;
    }
    // headings
    let m;
    if ((m = line.match(/^(#{1,4})\s+(.*)$/))) {
      const lvl = m[1].length;
      html += `<h${lvl}>${inline(m[2])}</h${lvl}>`;
      i++; continue;
    }
    // hr
    if (/^---+\s*$/.test(line)) { html += "<hr/>"; i++; continue; }
    // blockquote
    if (/^>\s?/.test(line)) {
      let buf = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) { buf.push(lines[i].replace(/^>\s?/, "")); i++; }
      html += `<blockquote>${inline(buf.join(" "))}</blockquote>`;
      continue;
    }
    // ordered list
    if (/^\d+\.\s+/.test(line)) {
      let items = [];
      while (i < lines.length && /^\d+\.\s+/.test(lines[i])) { items.push(lines[i].replace(/^\d+\.\s+/, "")); i++; }
      html += "<ol>" + items.map(it => `<li>${inline(it)}</li>`).join("") + "</ol>";
      continue;
    }
    // unordered list
    if (/^[-*]\s+/.test(line)) {
      let items = [];
      while (i < lines.length && /^[-*]\s+/.test(lines[i])) { items.push(lines[i].replace(/^[-*]\s+/, "")); i++; }
      html += "<ul>" + items.map(it => `<li>${inline(it)}</li>`).join("") + "</ul>";
      continue;
    }
    // blank
    if (/^\s*$/.test(line)) { i++; continue; }
    // paragraph (gather consecutive non-block lines)
    let buf = [line]; i++;
    while (i < lines.length && !/^\s*$/.test(lines[i]) && !/^(#{1,4}\s|>|```|[-*]\s|\d+\.\s|---)/.test(lines[i]) && !lines[i].includes("|")) {
      buf.push(lines[i]); i++;
    }
    html += `<p>${inline(buf.join(" "))}</p>`;
  }
  return html;
}

const Markdown = ({ source }) => (
  <div className="md" dangerouslySetInnerHTML={{ __html: mdToHtml(source || "") }} />
);

// embedding status badge
function EmbedBadge({ status }) {
  const map = {
    indexed: { dot: "dot-green", label: "indexed" },
    pending: { dot: "dot-amber", label: "pending" },
    stale:   { dot: "dot-gray",  label: "stale" },
  };
  const s = map[status] || map.stale;
  return <span className="badge"><i className={"dot " + s.dot} />{s.label}</span>;
}

function AccessBadge({ access }) {
  const I = window.Icons;
  const map = {
    public:  { ico: <I.globe />, label: "public" },
    team:    { ico: <I.users />, label: "team" },
    private: { ico: <I.lock />,  label: "private" },
  };
  const s = map[access] || map.team;
  return <span className="badge">{s.ico}{s.label}</span>;
}

// avatar with hue
function Avatar({ name, hue = "256", agent = false }) {
  const init = window.KB.initials(name);
  const bg = agent ? "var(--accent-soft)" : `oklch(0.92 0.04 ${hue})`;
  const fg = agent ? "var(--accent)" : `oklch(0.45 0.13 ${hue})`;
  const bd = agent ? "var(--accent-line)" : `oklch(0.84 0.06 ${hue})`;
  return <span className="avatar" style={{ background: bg, color: fg, border: `1px solid ${bd}` }}>{init}</span>;
}

window.Lib = { mdToHtml, Markdown, EmbedBadge, AccessBadge, Avatar };
