// palette.jsx — Cmd-K search: full-text + semantic, keyboard navigable.
const { useState: useStateP, useEffect: useEffectP, useRef: useRefP, useMemo: useMemoP } = React;

function Palette({ docs, onOpen, onClose }) {
  const I = window.Icons;
  const { folderName } = window.KB;
  const [q, setQ] = useStateP("");
  const [mode, setMode] = useStateP("semantic"); // semantic | fulltext
  const [sel, setSel] = useStateP(0);
  const inputRef = useRefP(null);

  useEffectP(() => { inputRef.current && inputRef.current.focus(); }, []);

  // Build results. Fulltext = substring on title/body; semantic = a faux
  // relevance score that also matches conceptually-related docs.
  const results = useMemoP(() => {
    const k = q.trim().toLowerCase();
    if (!k) {
      return docs.filter((d) => d.star || d.reads > 1000).slice(0, 6).map((d) => ({ d, snippet: firstLine(d.body), score: null }));
    }
    if (mode === "fulltext") {
      return docs
        .map((d) => {
          const hay = (d.title + " " + d.body).toLowerCase();
          const idx = hay.indexOf(k);
          if (idx === -1) return null;
          return { d, snippet: snippetAround(d.body, k), score: null };
        })
        .filter(Boolean)
        .slice(0, 8);
    }
    // semantic: score by token overlap + title boost + concept map, fuzzy
    const concept = conceptExpand(k);
    return docs
      .map((d) => {
        const text = (d.title + " " + d.tags.join(" ") + " " + d.body).toLowerCase();
        let score = 0;
        concept.forEach((tok) => { if (text.includes(tok)) score += tok.length > 4 ? 2 : 1; });
        if (d.title.toLowerCase().includes(k)) score += 5;
        if (score === 0) return null;
        const sim = Math.min(0.98, 0.55 + score * 0.06);
        return { d, snippet: snippetAround(d.body, concept[0] || k), score: sim };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);
  }, [q, mode, docs]);

  useEffectP(() => { setSel(0); }, [q, mode]);

  const onKey = (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(results.length - 1, s + 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(0, s - 1)); }
    else if (e.key === "Enter" && results[sel]) { onOpen(results[sel].d.id); }
    else if (e.key === "Escape") { onClose(); }
  };

  return (
    <div className="overlay" onMouseDown={onClose}>
      <div className="palette" onMouseDown={(e) => e.stopPropagation()} onKeyDown={onKey}>
        <div className="palette-in">
          <I.search />
          <input ref={inputRef} placeholder="Search the knowledge base…" value={q} onChange={(e) => setQ(e.target.value)} />
          <div className="palette-mode">
            <button data-on={mode === "semantic"} onClick={() => setMode("semantic")}>semantic</button>
            <button data-on={mode === "fulltext"} onClick={() => setMode("fulltext")}>full-text</button>
          </div>
        </div>

        <div className="palette-list">
          <div className="palette-sec">
            {q.trim() ? `${results.length} result${results.length === 1 ? "" : "s"} · ${mode === "semantic" ? "ranked by vector similarity" : "exact matches"}` : "Suggested"}
          </div>
          {results.length === 0 ? (
            <div className="empty" style={{ padding: "30px 10px" }}>
              <I.search /><h3>No matches</h3>
              <p className="hint">Try {mode === "fulltext" ? "semantic" : "full-text"} mode for broader recall.</p>
            </div>
          ) : results.map((r, i) => (
            <div key={r.d.id} className="palette-item" data-active={i === sel}
                 onMouseEnter={() => setSel(i)} onClick={() => onOpen(r.d.id)}>
              <span className="ico"><I.file /></span>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div className="pi-title">{r.d.title}</div>
                <div className="pi-snip" dangerouslySetInnerHTML={{ __html: r.snippet }} />
              </div>
              {r.score != null && <span className="score">{(r.score * 100).toFixed(0)}%</span>}
              <span className="pi-path">{folderName(r.d.folder)}</span>
            </div>
          ))}
        </div>

        <div className="palette-foot">
          <span className="grp"><span className="kbd">↑</span><span className="kbd">↓</span> navigate</span>
          <span className="grp"><span className="kbd">↵</span> open</span>
          <span className="grp"><span className="kbd">esc</span> close</span>
          <span style={{ marginLeft: "auto", fontFamily: "var(--font-mono)" }}>via <span style={{ color: "var(--accent)" }}>search_docs</span></span>
        </div>
      </div>
    </div>
  );
}

function firstLine(body) {
  const line = (body || "").split("\n").find((l) => l.trim() && !l.startsWith("#")) || "";
  return escapeHtml(line.replace(/[#*`>]/g, "").trim().slice(0, 90));
}
function snippetAround(body, term) {
  const clean = (body || "").replace(/[#*`>|]/g, " ").replace(/\s+/g, " ").trim();
  const i = clean.toLowerCase().indexOf((term || "").toLowerCase());
  if (i === -1 || !term) return escapeHtml(clean.slice(0, 96));
  const start = Math.max(0, i - 30);
  const slice = clean.slice(start, start + 96);
  const re = new RegExp("(" + escapeReg(term) + ")", "ig");
  return (start > 0 ? "…" : "") + escapeHtml(slice).replace(re, "<mark>$1</mark>");
}
// fake concept expansion so "search" also surfaces "retrieval", etc.
function conceptExpand(k) {
  const map = {
    search: ["search", "retrieval", "query", "semantic", "vector"],
    auth: ["auth", "token", "permission", "scope", "security"],
    index: ["index", "embed", "vector", "chunk", "ingest"],
    agent: ["agent", "mcp", "tool", "claude", "cursor"],
    error: ["error", "drift", "runbook", "escalate", "stale"],
    rate: ["rate", "limit", "429", "throttle"],
  };
  const base = k.split(/\s+/).filter(Boolean);
  const extra = [];
  base.forEach((b) => Object.keys(map).forEach((key) => { if (b.includes(key) || key.includes(b)) extra.push(...map[key]); }));
  return [...new Set([...base, ...extra])];
}
function escapeHtml(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function escapeReg(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

window.Palette = Palette;
