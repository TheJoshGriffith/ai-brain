// icons.jsx — stroke-based icon set (Lucide-style geometry), shared via window.
// Each is a small functional component taking no props; uses currentColor.
const S = ({ children, vb = "0 0 24 24" }) => (
  <svg viewBox={vb} fill="none" stroke="currentColor" strokeWidth="1.7"
       strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{children}</svg>
);

const Icons = {
  brain: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 5a3 3 0 0 0-5.9-.7A2.6 2.6 0 0 0 3.5 8 2.6 2.6 0 0 0 4 12.5a2.6 2.6 0 0 0 1.6 4.2A2.6 2.6 0 0 0 12 18z"/>
      <path d="M12 5a3 3 0 0 1 5.9-.7A2.6 2.6 0 0 1 20.5 8 2.6 2.6 0 0 1 20 12.5a2.6 2.6 0 0 1-1.6 4.2A2.6 2.6 0 0 1 12 18z"/>
      <path d="M12 5v13"/>
    </svg>
  ),
  home: () => <S><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h14V9.5"/><path d="M9.5 20v-6h5v6"/></S>,
  docs: () => <S><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h6"/></S>,
  file: () => <S><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></S>,
  search: () => <S><circle cx="11" cy="11" r="7"/><path d="m20 20-3.2-3.2"/></S>,
  folder: () => <S><path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></S>,
  folderOpen: () => <S><path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2"/><path d="m3 9 1.7 8.4A2 2 0 0 0 6.7 19h11.2a2 2 0 0 0 2-1.6L21 11H6.2a2 2 0 0 0-2 1.6z"/></S>,
  shield: () => <S><path d="M12 3 5 6v5c0 4.2 3 7.6 7 9 4-1.4 7-4.8 7-9V6z"/></S>,
  settings: () => <S><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/></S>,
  plug: () => <S><path d="M9 3v6M15 3v6"/><path d="M7 9h10v3a5 5 0 0 1-10 0z"/><path d="M12 17v4"/></S>,
  star: () => <S><path d="m12 3 2.6 5.5L20 9.3l-4 4 1 5.7-5-2.8-5 2.8 1-5.7-4-4 5.4-.8z"/></S>,
  tag: () => <S><path d="M3 12V5a2 2 0 0 1 2-2h7l9 9-9 9z"/><circle cx="8" cy="8" r="1.3" fill="currentColor" stroke="none"/></S>,
  clock: () => <S><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></S>,
  user: () => <S><circle cx="12" cy="8" r="3.6"/><path d="M5 20a7 7 0 0 1 14 0"/></S>,
  users: () => <S><circle cx="9" cy="8" r="3.2"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M16 5.2a3.2 3.2 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/></S>,
  bot: () => <S><rect x="4" y="8" width="16" height="11" rx="2.5"/><path d="M12 8V4M9 13h.01M15 13h.01M2 13v2M22 13v2"/></S>,
  eye: () => <S><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="2.6"/></S>,
  edit: () => <S><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></S>,
  preview: () => <S><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 14h8M8 17h5"/></S>,
  check: () => <S><path d="M5 12.5 10 17l9-10"/></S>,
  copy: () => <S><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/></S>,
  chevR: () => <S><path d="m9 6 6 6-6 6"/></S>,
  chevD: () => <S><path d="m6 9 6 6 6-6"/></S>,
  plus: () => <S><path d="M12 5v14M5 12h14"/></S>,
  dots: () => <S><circle cx="12" cy="5" r="1.3" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="12" cy="19" r="1.3" fill="currentColor" stroke="none"/></S>,
  filter: () => <S><path d="M3 5h18l-7 8v6l-4-2v-4z"/></S>,
  grid: () => <S><rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/></S>,
  list: () => <S><path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/></S>,
  history: () => <S><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 4v4h4"/><path d="M12 8v4l3 2"/></S>,
  link: () => <S><path d="M9 15 15 9"/><path d="M11 6.5 13 4.5a4 4 0 0 1 6 6l-2 2"/><path d="M13 17.5 11 19.5a4 4 0 0 1-6-6l2-2"/></S>,
  globe: () => <S><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.5 2.5 15 0 18M12 3c-2.5 2.5-2.5 15 0 18"/></S>,
  lock: () => <S><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></S>,
  zap: () => <S><path d="M13 3 5 13h6l-1 8 8-10h-6z"/></S>,
  spark: () => <S><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18"/></S>,
  arrowUp: () => <S><path d="M12 19V5M6 11l6-6 6 6"/></S>,
  arrowDown: () => <S><path d="M12 5v14M18 13l-6 6-6-6"/></S>,
  cmd: () => <S><path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/></S>,
  enter: () => <S><path d="M20 5v6a3 3 0 0 1-3 3H5"/><path d="m9 10-4 4 4 4"/></S>,
  layers: () => <S><path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/></S>,
  db: () => <S><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/></S>,
  x: () => <S><path d="M6 6l12 12M18 6 6 18"/></S>,
  trash: () => <S><path d="M4 7h16M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13"/></S>,
  download: () => <S><path d="M12 4v11M8 11l4 4 4-4M5 19h14"/></S>,
  branch: () => <S><circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="8" r="2.5"/><path d="M6 8.5v7M18 10.5c0 4-5 2.5-12 5"/></S>,
  warn: () => <S><path d="M12 4 2 20h20z"/><path d="M12 10v4M12 17h.01"/></S>,
  key: () => <S><circle cx="8" cy="14" r="4"/><path d="m11 11 9-9M17 5l2 2M14 8l2 2"/></S>,
};

window.Icons = Icons;
