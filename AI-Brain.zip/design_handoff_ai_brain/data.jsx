// data.jsx — mock knowledge base data, shared via window.

const FOLDERS = [
  { id: "eng",      name: "Engineering",     icon: "folder" },
  { id: "api",      name: "API Reference",   icon: "folder" },
  { id: "runbooks", name: "Runbooks",        icon: "folder" },
  { id: "adr",      name: "Decisions (ADR)", icon: "folder" },
  { id: "product",  name: "Product",         icon: "folder" },
  { id: "onboard",  name: "Onboarding",      icon: "folder" },
];

const TAGS = ["architecture", "api", "security", "onboarding", "infra", "draft", "deprecated", "ml", "billing", "auth"];

// markdown bodies kept short but real-feeling
const MD = {
  ingest: `# Vector Ingestion Pipeline

The ingestion pipeline turns raw documents into retrievable knowledge. It runs
on every write through the MCP \`write_doc\` tool and on manual edits in the UI.

## Stages

1. **Normalize** — strip frontmatter, resolve relative links, collapse whitespace.
2. **Chunk** — split on semantic boundaries (~512 tokens, 64-token overlap).
3. **Embed** — \`text-embedding-3-large\`, 3072 dims, batched at 96/req.
4. **Index** — upsert into the HNSW store keyed by \`doc_id:chunk_idx\`.

> Re-indexing is incremental. Only chunks whose content hash changed are
> re-embedded, which keeps the average write under 400ms.

## Status semantics

| Status   | Meaning                                          |
|----------|--------------------------------------------------|
| indexed  | All chunks embedded and queryable                |
| pending  | Queued; serving stale vectors until complete     |
| stale    | Source changed, re-embed scheduled               |

## Retrieval

Agents query through \`search_docs\`. Results blend dense (cosine) and sparse
(BM25) scores with a reciprocal-rank fusion pass before returning the top *k*.`,

  auth: `# Authentication Architecture

All access — human and agent — flows through a single token broker. There are
no long-lived credentials in application code.

## Token types

- **Session tokens** — short-lived (15m), issued to browser sessions.
- **Agent tokens** — scoped per MCP connection, rotated every 24h.
- **Service tokens** — machine-to-machine, mTLS pinned.

\`\`\`ts
const ctx = await broker.verify(token, {
  audience: "kb.read",
  require: ["doc:read"],
});
\`\`\`

## Scopes

Every token carries an explicit scope set. The MCP server **never** widens
scope — it can only attenuate. An agent granted \`doc:read\` on \`Engineering\`
cannot read \`Runbooks\` even if it asks.`,

  oncall: `# On-Call Runbook: Index Drift

When semantic search returns stale or empty results, the vector index has
likely drifted from source.

## Symptoms

- \`search_docs\` returns < 3 results for known queries
- Embedding status stuck on **pending** for > 10 minutes

## Resolution

1. Check the indexer queue depth: \`kb ops queue\`
2. If depth > 5k, scale the embed workers: \`kb ops scale embed 6\`
3. Force a reconcile pass for the affected folder.

> Escalate to #kb-infra if queue does not drain within 15 minutes.`,

  adr: `# ADR-014: MCP as the Single Write Path

**Status:** Accepted · **Date:** 2026-04-22

## Context

Agents and humans both mutate the knowledge base. Divergent write paths led to
index drift and permission gaps.

## Decision

All writes — UI and agent — go through the MCP \`write_doc\` tool. The editor in
this app is a thin client over the same endpoint.

## Consequences

- Single audit trail for every mutation
- Permissions enforced in exactly one place
- The editor cannot bypass ingestion, so the index never drifts from source`,

  onboard: `# Connecting Your First Agent

This guide gets a coding agent reading from the knowledge base in under five
minutes.

## 1. Create an agent token

Settings → MCP → **New connection**. Scope it to the folders the agent needs.

## 2. Add the server to your client

\`\`\`json
{
  "mcpServers": {
    "ai-brain": {
      "url": "https://mcp.ai-brain.dev/sse",
      "headers": { "Authorization": "Bearer abk_live_..." }
    }
  }
}
\`\`\`

## 3. Verify

Ask your agent to call \`list_folders\`. You should see only the folders the
token is scoped to.`,

  rate: `# API Rate Limits

Limits are per-token and reset on a sliding 60-second window.

| Tool          | Limit       |
|---------------|-------------|
| search_docs   | 120 / min   |
| read_doc      | 600 / min   |
| write_doc     | 60 / min    |
| list_folders  | 300 / min   |

Exceeding a limit returns \`429\` with a \`Retry-After\` header. The MCP client
backs off automatically.`,
};

// generate a believable updated time string
const DOCS = [
  { id: "d1",  title: "Vector Ingestion Pipeline", folder: "eng", tags: ["architecture", "ml", "infra"], updated: "2h ago", by: "Maya Chen", words: 612, access: "team", embed: "indexed", reads: 1284, star: true, body: MD.ingest },
  { id: "d2",  title: "Authentication Architecture", folder: "eng", tags: ["architecture", "security", "auth"], updated: "1d ago", by: "Dev Patel", words: 430, access: "team", embed: "indexed", reads: 902, star: true, body: MD.auth },
  { id: "d3",  title: "On-Call Runbook: Index Drift", folder: "runbooks", tags: ["infra", "ml"], updated: "5h ago", by: "agent · cursor", words: 198, access: "team", embed: "indexed", reads: 341, star: false, body: MD.oncall },
  { id: "d4",  title: "ADR-014: MCP as Single Write Path", folder: "adr", tags: ["architecture", "api"], updated: "3d ago", by: "Maya Chen", words: 224, access: "team", embed: "indexed", reads: 567, star: false, body: MD.adr },
  { id: "d5",  title: "Connecting Your First Agent", folder: "onboard", tags: ["onboarding", "api"], updated: "6h ago", by: "Lena Ruiz", words: 287, access: "public", embed: "indexed", reads: 2103, star: true, body: MD.onboard },
  { id: "d6",  title: "API Rate Limits", folder: "api", tags: ["api"], updated: "2d ago", by: "Dev Patel", words: 142, access: "public", embed: "indexed", reads: 1455, star: false, body: MD.rate },
  { id: "d7",  title: "search_docs — Tool Spec", folder: "api", tags: ["api", "ml"], updated: "4d ago", by: "agent · claude", words: 510, access: "public", embed: "indexed", reads: 3201, star: false, body: "# search_docs\n\nHybrid dense + sparse retrieval over the knowledge base.\n\n## Parameters\n\n- \`query\` *(string, required)* — natural language query\n- \`k\` *(int, default 8)* — number of results\n- \`folder\` *(string, optional)* — restrict to a folder\n\n## Returns\n\nAn array of chunks with \`doc_id\`, \`title\`, \`snippet\`, and \`score\`." },
  { id: "d8",  title: "Billing & Usage Metering", folder: "product", tags: ["billing", "draft"], updated: "1w ago", by: "Lena Ruiz", words: 388, access: "private", embed: "stale", reads: 88, star: false, body: "# Billing & Usage Metering\n\n> **Draft** — numbers not final.\n\nUsage is metered per embedded token and per agent query." },
  { id: "d9",  title: "Embedding Model Migration", folder: "eng", tags: ["ml", "infra", "draft"], updated: "3h ago", by: "agent · claude", words: 0, access: "team", embed: "pending", reads: 12, star: false, body: "# Embedding Model Migration\n\n> **Draft** — being written by an agent right now.\n\nPlan to move from 3-large to a fine-tuned in-house model." },
  { id: "d10", title: "Deprecated: v1 REST Endpoints", folder: "api", tags: ["api", "deprecated"], updated: "2mo ago", by: "Dev Patel", words: 256, access: "public", embed: "indexed", reads: 47, star: false, body: "# Deprecated: v1 REST Endpoints\n\n> These endpoints are removed as of v2. Use the MCP tools instead." },
  { id: "d11", title: "Permission Model", folder: "eng", tags: ["security", "auth", "architecture"], updated: "4d ago", by: "Maya Chen", words: 470, access: "team", embed: "indexed", reads: 712, star: false, body: "# Permission Model\n\nRole-based, folder-scoped. Three roles: Owner, Editor, Viewer. Agent tokens inherit a subset of a role's scopes." },
  { id: "d12", title: "Welcome to the Knowledge Base", folder: "onboard", tags: ["onboarding"], updated: "1w ago", by: "Lena Ruiz", words: 180, access: "public", embed: "indexed", reads: 1890, star: false, body: "# Welcome\n\nThis is the source of truth for the team and every agent we run. Start with **Connecting Your First Agent**." },
];

const ACTIVITY = [
  { kind: "agent", who: "claude-code", what: "read this doc", when: "4 min ago" },
  { kind: "human", who: "Maya Chen", what: "edited +42 −8", when: "2h ago" },
  { kind: "agent", who: "cursor", what: "read this doc", when: "3h ago" },
  { kind: "agent", who: "claude-code", what: "via search_docs", when: "5h ago" },
  { kind: "human", who: "Dev Patel", what: "tagged #infra", when: "1d ago" },
];

const AGENTS = [
  { id: "a1", name: "claude-code", client: "Claude Code", status: "active", scopes: ["doc:read", "doc:write", "search"], reads: 8421, writes: 142, last: "live now" },
  { id: "a2", name: "cursor", client: "Cursor", status: "active", scopes: ["doc:read", "search"], reads: 5108, writes: 0, last: "2 min ago" },
  { id: "a3", name: "ci-indexer", client: "Service token", status: "active", scopes: ["doc:read", "doc:write", "admin"], reads: 412, writes: 980, last: "30s ago" },
  { id: "a4", name: "support-bot", client: "Custom", status: "idle", scopes: ["doc:read"], reads: 233, writes: 0, last: "6h ago" },
];

const MEMBERS = [
  { id: "m1", name: "Maya Chen", email: "maya@ai-brain.dev", role: "Owner", color: "256", last: "Active now" },
  { id: "m2", name: "Dev Patel", email: "dev@ai-brain.dev", role: "Editor", color: "150", last: "12m ago" },
  { id: "m3", name: "Lena Ruiz", email: "lena@ai-brain.dev", role: "Editor", color: "30", last: "1h ago" },
  { id: "m4", name: "Sam Okafor", email: "sam@ai-brain.dev", role: "Viewer", color: "300", last: "Yesterday" },
];

const MCP_TOOLS = [
  { name: "search_docs", desc: "Hybrid semantic + keyword retrieval", scopes: ["search"] },
  { name: "read_doc", desc: "Fetch full document by id or path", scopes: ["doc:read"] },
  { name: "write_doc", desc: "Create or update a document (re-indexed)", scopes: ["doc:write"] },
  { name: "list_folders", desc: "Enumerate folders the token can see", scopes: ["doc:read"] },
  { name: "get_history", desc: "Read version history & diffs", scopes: ["doc:read"] },
];

function initials(name) {
  return name.replace(/^agent · /, "").split(/[\s_-]+/).slice(0, 2).map(s => s[0]?.toUpperCase() || "").join("");
}
function folderName(id) { return (FOLDERS.find(f => f.id === id) || {}).name || id; }

window.KB = { FOLDERS, TAGS, DOCS, ACTIVITY, AGENTS, MEMBERS, MCP_TOOLS, initials, folderName };
