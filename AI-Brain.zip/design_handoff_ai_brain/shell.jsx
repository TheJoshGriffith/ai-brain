// shell.jsx — app shell (nav + topbar), routing, state, and Tweaks wiring.
const { useState: useStateA, useEffect: useEffectA, useCallback } = React;

const FONTS = {
  geist: { sans: '"Geist", ui-sans-serif, system-ui, sans-serif', mono: '"Geist Mono", ui-monospace, monospace', label: "Geist" },
  plex:  { sans: '"IBM Plex Sans", ui-sans-serif, system-ui, sans-serif', mono: '"IBM Plex Mono", ui-monospace, monospace', label: "IBM Plex" },
  space: { sans: '"Space Grotesk", ui-sans-serif, system-ui, sans-serif', mono: '"Space Mono", ui-monospace, monospace', label: "Space" },
};

// Baked-in defaults (locked from Tweaks exploration):
const LAYOUT = "rail";       // rail navigation
const FONT_KEY = "geist";    // Geist typeface
const EDITOR_MODE = "toggle"; // Edit / Split / Preview toggle
const DENSITY = "regular";

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "system",
  "accent": "#3565F6"
}/*EDITMODE-END*/;

function App() {
  const I = window.Icons;
  const { FOLDERS } = window.KB;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [route, setRoute] = useStateA("kb");          // kb | editor | access | settings
  const [openId, setOpenId] = useStateA(null);
  const [paletteOpen, setPaletteOpen] = useStateA(false);
  const [docs, setDocs] = useStateA(window.KB.DOCS);

  // follow OS theme when theme === "system"
  const [systemDark, setSystemDark] = useStateA(
    typeof window !== "undefined" && window.matchMedia
      ? window.matchMedia("(prefers-color-scheme: dark)").matches : false);
  useEffectA(() => {
    if (!window.matchMedia) return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const on = (e) => setSystemDark(e.matches);
    mq.addEventListener ? mq.addEventListener("change", on) : mq.addListener(on);
    return () => { mq.removeEventListener ? mq.removeEventListener("change", on) : mq.removeListener(on); };
  }, []);

  // apply theme tokens
  useEffectA(() => {
    const r = document.documentElement;
    const dark = t.theme === "dark" || (t.theme === "system" && systemDark);
    r.setAttribute("data-theme", dark ? "dark" : "light");
    const f = FONTS[FONT_KEY] || FONTS.geist;
    r.style.setProperty("--font-sans", f.sans);
    r.style.setProperty("--font-mono", f.mono);
    r.style.setProperty("--accent", t.accent);
  }, [t.theme, t.accent, systemDark]);

  // global Cmd-K
  useEffectA(() => {
    const h = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPaletteOpen((p) => !p); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  const openDoc = useCallback((id) => { setOpenId(id); setRoute("editor"); setPaletteOpen(false); }, []);
  const toggleStar = useCallback((id) => setDocs((d) => d.map((x) => x.id === id ? { ...x, star: !x.star } : x)), []);
  const editDoc = useCallback((id, patch) => setDocs((d) => d.map((x) => x.id === id ? { ...x, ...patch } : x)), []);

  const openDoc_obj = docs.find((d) => d.id === openId);

  const NAV = [
    { group: "Workspace", items: [
      { id: "kb", label: "Knowledge base", icon: "docs", count: docs.length, action: () => setRoute("kb") },
      { id: "search", label: "Search", icon: "search", action: () => setPaletteOpen(true) },
    ]},
    { group: "Admin", items: [
      { id: "access", label: "Access control", icon: "shield", action: () => setRoute("access") },
      { id: "settings", label: "Settings", icon: "settings", action: () => setRoute("settings") },
    ]},
  ];

  const isActive = (id) => id === "search" ? false : (id === route || (id === "kb" && route === "editor"));

  const Brand = (
    <div className="brand">
      <span className="brand-mark"><span style={{ color: "var(--bg)" }}><I.brain /></span></span>
      <span className="brand-name">AI&#8209;Brain <span className="tag-chip">MCP</span></span>
    </div>
  );

  const NavItems = ({ topnav }) => NAV.map((sec) => (
    <React.Fragment key={sec.group}>
      {!topnav && <div className="nav-label">{sec.group}</div>}
      {sec.items.map((it) => {
        const Ico = I[it.icon];
        return (
          <button key={it.id} className="nav-item" data-active={isActive(it.id)} onClick={it.action} title={it.label}>
            <Ico /><span className="label">{it.label}</span>
            {it.count != null && <span className="count">{it.count}</span>}
          </button>
        );
      })}
    </React.Fragment>
  ));

  // crumbs
  const crumbs = (() => {
    if (route === "editor" && openDoc_obj) return ["Knowledge base", window.KB.folderName(openDoc_obj.folder), openDoc_obj.title];
    if (route === "access") return ["Access control"];
    if (route === "settings") return ["Settings"];
    return ["Knowledge base"];
  })();

  return (
    <div className="app" data-layout={LAYOUT} data-density={DENSITY}>
      {/* sidebar (left / rail layouts) */}
      <div className="sidebar">
        {Brand}
        <div className="nav"><NavItems /></div>
        <div className="sidebar-foot">
          <div className="mcp-card">
            <div className="row">
              <span className="ttl"><span style={{ color: "var(--accent)" }}><I.plug /></span> MCP server</span>
              <span className="badge"><i className="dot dot-green" />live</span>
            </div>
            <div className="sub">mcp.ai-brain.dev/sse</div>
            <div className="row">
              <span className="sub">2 agents · 12.4k chunks</span>
              <button className="icon-btn" style={{ width: 22, height: 22 }} onClick={() => setRoute("settings")}><I.chevR /></button>
            </div>
          </div>
        </div>
      </div>

      <div className="main">
        <div className="topbar">
          {/* top-layout inline nav */}
          <div className="topnav-brand">{Brand}</div>
          <div className="topnav"><NavItems topnav /></div>

          {/* crumbs for sidebar layouts */}
          {LAYOUT !== "top" && (
            <div className="crumbs">
              {crumbs.map((c, i) => (
                <React.Fragment key={i}>
                  {i > 0 && <span className="sep"><I.chevR /></span>}
                  <span className={"crumb " + (i === crumbs.length - 1 ? "cur" : "link")}
                        onClick={() => i === 0 && setRoute("kb")}>{c}</span>
                </React.Fragment>
              ))}
            </div>
          )}

          <div className="spacer" />
          <div className="searchbtn" onClick={() => setPaletteOpen(true)}>
            <I.search /><span>Search…</span>
            <span className="kbd">⌘K</span>
          </div>
          <button className="icon-btn" title="History"><I.history /></button>
          <button className="btn btn-primary btn-sm" onClick={() => { setRoute("kb"); }}><I.plus />New</button>
        </div>

        {route === "kb" && <div className="content" style={{ padding: 0 }}><KBView docs={docs} onOpen={openDoc} toggleStar={toggleStar} /></div>}
        {route === "editor" && openDoc_obj && <EditorView doc={openDoc_obj} editorMode={EDITOR_MODE} onChange={editDoc} onBack={() => setRoute("kb")} />}
        {route === "access" && <AccessView />}
        {route === "settings" && <SettingsView />}
      </div>

      {paletteOpen && <Palette docs={docs} onOpen={openDoc} onClose={() => setPaletteOpen(false)} />}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Appearance" />
        <TweakRadio label="Theme" value={t.theme}
          options={[{ value: "system", label: "System" }, { value: "light", label: "Light" }, { value: "dark", label: "Dark" }]}
          onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={t.accent}
          options={["#3565F6", "#7A5AF0", "#16A06A", "#E0822A", "#E0473C"]}
          onChange={(v) => setTweak("accent", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
