// views-access.jsx — permissions & access control (members + agent tokens).
function AccessView() {
  const I = window.Icons;
  const { MEMBERS, AGENTS } = window.KB;
  const { Avatar } = window.Lib;

  const roleColor = (r) => r === "Owner" ? "accent" : "";

  return (
    <div className="content">
      <div className="wrap">
        <div className="page-head">
          <div>
            <h1 className="page-title">Access control</h1>
            <p className="page-sub">Manage who — and which agents — can read and write the knowledge base. Permissions are folder-scoped and enforced at the single MCP write path.</p>
          </div>
          <div className="actions">
            <button className="btn btn-sm"><I.users />Invite</button>
            <button className="btn btn-primary btn-sm"><I.plus />New agent token</button>
          </div>
        </div>

        <div className="stat-row">
          <div className="stat"><span className="k"><I.users />Members</span><span className="v">{MEMBERS.length}</span></div>
          <div className="stat"><span className="k"><I.bot />Agent tokens</span><span className="v">{AGENTS.length}</span></div>
          <div className="stat"><span className="k"><I.zap />Active now</span><span className="v">2 <small>agents</small></span></div>
          <div className="stat"><span className="k"><I.shield />Roles</span><span className="v">3</span></div>
        </div>

        <div className="panel-card">
          <div className="ph">
            <span className="ico"><I.users /></span>
            <div><h3>People</h3><p>Human collaborators and their roles.</p></div>
          </div>
          <table className="tbl" style={{ padding: "0 6px" }}>
            <thead>
              <tr><th style={{ paddingLeft: 18 }}>Member</th><th>Role</th><th>Scopes</th><th style={{ paddingRight: 18 }}>Last active</th><th style={{ width: 32 }}></th></tr>
            </thead>
            <tbody>
              {MEMBERS.map((m) => (
                <tr key={m.id} style={{ cursor: "default" }}>
                  <td style={{ paddingLeft: 18 }}>
                    <div className="doc-cell">
                      <Avatar name={m.name} hue={m.color} />
                      <span><div className="doc-title">{m.name}</div><div className="doc-path">{m.email}</div></span>
                    </div>
                  </td>
                  <td><span className={"badge " + roleColor(m.role)}>{m.role}</span></td>
                  <td><span className="hint">{m.role === "Viewer" ? "read all folders" : "read + write all folders"}</span></td>
                  <td className="muted">{m.last}</td>
                  <td><button className="icon-btn"><I.dots /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="panel-card">
          <div className="ph">
            <span className="ico"><I.bot /></span>
            <div><h3>Agent tokens</h3><p>MCP connections. Each token is scoped and rotates automatically.</p></div>
          </div>
          <table className="tbl">
            <thead>
              <tr><th style={{ paddingLeft: 18 }}>Connection</th><th>Client</th><th>Scopes</th><th>Activity</th><th style={{ paddingRight: 18 }}>Last seen</th><th style={{ width: 32 }}></th></tr>
            </thead>
            <tbody>
              {AGENTS.map((a) => (
                <tr key={a.id} style={{ cursor: "default" }}>
                  <td style={{ paddingLeft: 18 }}>
                    <div className="doc-cell">
                      <span className="avatar" style={{ background: "var(--accent-soft)", color: "var(--accent)", border: "1px solid var(--accent-line)" }}><I.bot /></span>
                      <span>
                        <div className="doc-title" style={{ fontFamily: "var(--font-mono)", fontSize: 12.5 }}>{a.name}</div>
                        <div className="doc-path">abk_live_••••{a.id}{a.id}</div>
                      </span>
                    </div>
                  </td>
                  <td className="muted">{a.client}</td>
                  <td>
                    <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                      {a.scopes.map((s) => <span key={s} className="scope-tag">{s}</span>)}
                    </div>
                  </td>
                  <td className="mono" style={{ whiteSpace: "nowrap" }}>{a.reads.toLocaleString()}↓ {a.writes}↑</td>
                  <td>
                    <span className="badge"><i className={"dot " + (a.status === "active" ? "dot-green" : "dot-gray")} />{a.last}</span>
                  </td>
                  <td><button className="icon-btn"><I.dots /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

window.AccessView = AccessView;
